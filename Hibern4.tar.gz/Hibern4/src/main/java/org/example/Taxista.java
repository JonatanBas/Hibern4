package org.example;

import jakarta.persistence.*;

import java.util.List;

@Entity
@Table(name = "taxistas")
@DiscriminatorValue(value = "T")
public class Taxista extends Persona
{
    //ATRIBUTOS
    @Column
    String registration;
    @Column
    double salary;
    @ManyToMany(cascade = CascadeType.PERSIST)
    @JoinTable(name = "TaxistasClientes",
                joinColumns =
                @JoinColumn(name = "TaxistasID",referencedColumnName = "id"),
                inverseJoinColumns =
                @JoinColumn(name = "ProfesoresID",referencedColumnName = "id")
    )
    protected List<Cliente> listaClientes;

    //CONSTRUCTORES
    public Taxista(int id, String name, int age, double weight, int registration, double salary) {
        super((long) id, name, age, weight);
        this.registration = String.valueOf(registration);
        this.salary = salary;
    }
    /*public Taxista(String registration, double salary) {
        this.registration = registration;
        this.salary = salary;
    }*/

    public Taxista(){

    }

    //SETTERS
    public void setRegistration(String registration) {
        this.registration = registration;
    }
    public void setSalary(double salary) {
        this.salary = salary;
    }

    //GETTERS
    public String getRegistration() {
        return registration;
    }

    public double getSalary() {
        return salary;
    }

    //MÉTODOS
    @Override
    public String toString() {
        return "Taxista{" +
                "registration='" + registration + '\'' +
                ", salary=" + salary +
                ", id=" + id +
                ", name='" + name + '\'' +
                ", age=" + age +
                ", weight=" + weight +
                '}';
    }

    public void setListaClientes(List<Cliente> listaClientes) {
    }
}
