package org.example;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import java.util.ArrayList;
import java.util.List;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
        SessionFactory sf = HibernateUtil.getSessionFactory();
        Session ss = sf.openSession();
        Transaction tr = ss.beginTransaction();

        List<Taxista>listaTaxistas = new ArrayList<Taxista>();
        List<Cliente>listaClientes = new ArrayList<Cliente>();

        Taxista t1 = new Taxista(1,"Ricardo",58,70,123456,2000);
        Taxista t2 = new Taxista(2,"Miguel",44,80,987654,2000);
        Cliente c1 = new Cliente(3,"Jonás",40,65,123456789,800);
        Cliente c2 = new Cliente(4,"Godofredo",55,95,987654321,600);

        listaTaxistas.add(t1);
        listaTaxistas.add(t2);
        listaClientes.add(c1);
        listaClientes.add(c2);

        t1.setListaClientes(listaClientes);
        t2.setListaClientes(listaClientes);
        c1.setListaTaxistas(listaTaxistas);
        c2.setListaTaxistas(listaTaxistas);

        ss.persist(t1);
        ss.persist(t2);

        tr.commit();
    }
}
