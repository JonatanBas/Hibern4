package org.example;

import jakarta.persistence.*;

import java.util.List;

@Entity
@Table(name = "clientes")
@DiscriminatorValue(value = "C")
public class Cliente extends Persona
{
    //ATRIBUTOS
    @Column
    String phoneNumber;
    @Column
    double cash;


    //CONSTRUCTORES
    public Cliente(int id, String name, int age, double weight, int phoneNumber, double cash) {
        super((long) id, name, age, weight);
        this.phoneNumber = String.valueOf(phoneNumber);
        this.cash = cash;
    }
    /*public Cliente(String phoneNumber, double cash) {
        this.phoneNumber = phoneNumber;
        this.cash = cash;
    }*/
    public Cliente() {
    }

    //SETTERS
    /*public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }*/

    public void setCash(double cash) {
        this.cash = cash;
    }

    //GETTERS
    public String getPhoneNumber() {
        return phoneNumber;
    }

    public double getCash() {
        return cash;
    }

    //MÉTODOS
    @Override
    public String toString() {
        return "Cliente{" +
                "phoneNumber='" + phoneNumber + '\'' +
                ", cash=" + cash +
                ", id=" + id +
                ", name='" + name + '\'' +
                ", age=" + age +
                ", weight=" + weight +
                '}';
    }

    public void setListaTaxistas(List<Taxista> listaTaxistas) {
    }
}
