package org.example;

import jakarta.persistence.*;

import java.io.Serializable;

@Entity
@Table(name = "personas")
@DiscriminatorColumn(discriminatorType = DiscriminatorType.CHAR)
@DiscriminatorValue(value = "P")
public class Persona implements Serializable
{
    //ATRIBUTOS
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    Long id;
    @Column
    String name;
    @Column
    int age;
    @Column
    double weight;
    //CONSTRUCTORES
    public Persona(Long id, String name, int age, double weight) {
        this.id = id;
        this.name = name;
        this.age = age;
        this.weight = weight;
    }
    public Persona() {
    }
    //SETTERS
    /*public void setId(Long id) {
        this.id = id;
    }*/

    public void setName(String name) {
        this.name = name;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public void setWeight(double weight) {
        this.weight = weight;
    }

    //GETTERS
    public Long getId() {
        return id;
    }

    public String getName() {
        return name;
    }

    public int getAge() {
        return age;
    }

    public double getWeight() {
        return weight;
    }

    //MÉTODOS

    @Override
    public String toString() {
        return "Persona{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", age=" + age +
                ", weight=" + weight +
                '}';
    }

    public void setId(Long id) {
        this.id = id;
    }


}
